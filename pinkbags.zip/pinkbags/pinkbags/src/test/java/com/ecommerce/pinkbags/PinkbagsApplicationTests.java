package com.ecommerce.pinkbags;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PinkbagsApplicationTests {

	@Test
	void contextLoads() {
	}

}
